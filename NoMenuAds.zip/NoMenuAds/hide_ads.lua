function MenuComponentManager:create_newsfeed_gui()
end

function MenuComponentManager:create_new_heists_gui()
end
