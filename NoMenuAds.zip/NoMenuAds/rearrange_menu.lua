local PROFILE_LEFT = 0
local PROFILE_BOTTOM = 0

local alive = alive or function(o) return o ~= nil end

local timer = 0
local logged = {}
local patched = false

local function log_once(msg)
    if not logged[msg] then
        logged[msg] = true
        log("[NoMenuAds] " .. msg)
    end
end

local function get_panel(obj)
    if type(obj) ~= "table" then
        return nil
    end
    for _, key in ipairs({ "_panel", "_main_panel", "panel", "_object_panel" }) do
        local p = rawget(obj, key)
        if type(p) == "userdata" and alive(p) and p.set_visible then
            return p, key
        end
    end
    return nil
end

local function patch_creators()
    if patched or not MenuComponentManager then
        return
    end
    patched = true
    for name, fn in pairs(MenuComponentManager) do
        if type(name) == "string" and type(fn) == "function" then
            local l = name:lower()
            if l:find("notif", 1, true) and (l:find("create", 1, true) or l:find("setup", 1, true)) then
                MenuComponentManager[name] = function() end
                log_once("disabled creator " .. name)
            end
        end
    end
end

local function remove_object(mc, name, obj)
    log_once("removing '" .. name .. "'")
    local closed = false
    if type(obj.close) == "function" then
        closed = pcall(function() obj:close() end)
    end
    if not closed then
        local p = get_panel(obj)
        if p then
            pcall(function()
                local parent = p:parent()
                if parent then
                    parent:remove(p)
                end
            end)
        end
    end
    mc[name] = nil
end

local function move_profile(name, obj)
    local p, key = get_panel(obj)
    if p then
        log_once("moving '" .. name .. "' via " .. key)
        pcall(function()
            p:set_world_left(PROFILE_LEFT)
            local parent = p:parent()
            if parent then
                p:set_bottom(parent:h() - PROFILE_BOTTOM)
            end
        end)
    end
end

Hooks:Add("MenuUpdate", "NoMenuAds_Rearrange", function(t, dt)
    timer = timer - dt
    if timer > 0 then
        return
    end
    timer = 0.5

    pcall(patch_creators)

    local mc = managers.menu_component
    if not mc then
        return
    end

    local to_remove = {}
    for name, obj in pairs(mc) do
        if type(name) == "string" and type(obj) == "table" then
            local lname = name:lower()
            if lname:find("notif", 1, true) then
                table.insert(to_remove, { name, obj })
            elseif lname:find("profile", 1, true) then
                move_profile(name, obj)
            end
        end
    end
    for _, entry in ipairs(to_remove) do
        pcall(remove_object, mc, entry[1], entry[2])
    end
end)
