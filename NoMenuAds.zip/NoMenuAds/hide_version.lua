local alive = alive or function(o) return o ~= nil end

local timer = 0
local seen = {}

local function should_hide(s)
    if type(s) ~= "string" or #s > 40 then
        return false
    end
    return s:find("EpicMM", 1, true) ~= nil
        or s:find("%d+%.%d+%.%d+") ~= nil
        or s:find("159028", 1, true) ~= nil
end

local function scan(panel, depth, path)
    if depth > 6 or not alive(panel) then
        return
    end
    local children = panel:children()
    if not children then
        return
    end
    for i, child in ipairs(children) do
        if alive(child) then
            if child.children then
                scan(child, depth + 1, path .. "/" .. tostring(i))
            elseif child.text and child.set_visible then
                local s = child:text()
                if type(s) == "string" then
                    if #s < 60 and not seen[s] then
                        seen[s] = true
                        log("[NoMenuAds] saw text '" .. s .. "' at " .. path)
                    end
                    if should_hide(s) then
                        child:set_visible(false)
                        child:set_alpha(0)
                    end
                end
            end
        end
    end
end

local function add_ws(roots, ws)
    if ws and alive(ws) then
        local p = ws:panel()
        if p and alive(p) then
            table.insert(roots, p)
        end
    end
end

Hooks:Add("MenuUpdate", "NoMenuAds_HideVersion", function(t, dt)
    timer = timer - dt
    if timer > 0 then
        return
    end
    timer = 1

    local roots = {}

    local mc = managers.menu_component
    if mc then
        add_ws(roots, mc._ws)
        add_ws(roots, mc._fullscreen_ws)
    end

    local menu = managers.menu and managers.menu:active_menu()
    local r = menu and menu.renderer
    if r then
        add_ws(roots, r._ws)
        local ng = r.active_node_gui and r:active_node_gui()
        if ng then
            add_ws(roots, ng.ws)
        end
    end

    for i, p in ipairs(roots) do
        pcall(scan, p, 0, "root" .. i)
    end
end)
